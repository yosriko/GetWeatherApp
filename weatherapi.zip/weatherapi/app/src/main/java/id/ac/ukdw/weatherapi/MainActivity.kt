package com.example.myweather

import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import id.ac.ukdw.weatherapi.Example
import id.ac.ukdw.weatherapi.Main
import id.ac.ukdw.weatherapi.R
import id.ac.ukdw.weatherapi.weatherapi
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {
    var et: EditText? = null
    var tv: TextView? = null
    var url = "api.openweathermap.org/data/2.5/weather?q={city name}&appid={your api key}"
    var apikey = "9e970a47fbefc84286d09bb5d0708329"
    var manager: LocationManager? = null
    var locationListener: LocationListener? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        et = findViewById<EditText>(R.id.et)
        tv = findViewById<TextView>(R.id.tv)
    }

    fun getweather(v: View?) {
        val retrofit = Retrofit.Builder()
            .baseUrl("https://api.openweathermap.org/data/2.5/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        val myapi: weatherapi = retrofit.create(weatherapi::class.java)
        val examplecall: Call<Example> =
            myapi.getweather(et!!.getText().toString().trim { it <= ' ' }, apikey)
        examplecall.enqueue(object : Callback<Example?> {
            override fun onResponse(call: Call<Example?>, response: Response<Example?>) {
                if (response.code() == 404) {
                    Toast.makeText(
                        this@MainActivity,
                        "Please Enter a valid City",
                        Toast.LENGTH_LONG
                    ).show()
                } else if (!response.isSuccessful()) {
                    Toast.makeText(
                        this@MainActivity,
                        response.code().toString() + " ",
                        Toast.LENGTH_LONG
                    ).show()
                    return
                }
                val mydata: Example? = response.body()
                val main: Main? = mydata?.getMain()
                val temp: Double? = main?.getTemp()
                val temperature = (temp?.minus(273.15))?.toInt()
                tv!!.text = temperature.toString() + " C"
            }

            override fun onFailure(call: Call<Example?>, t: Throwable) {
                Toast.makeText(this@MainActivity, t.message, Toast.LENGTH_LONG).show()
            }
        })
    }
}
